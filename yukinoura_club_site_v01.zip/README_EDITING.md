# ゆきのうら倶楽部 公式サイト v0.1

## GitHubで公開する手順
1. GitHubで `shichangche-code/yukinoura_club.github.io` を開く
2. `Add file` → `Upload files`
3. このフォルダ内の `index.html` と `assets` フォルダの画像をアップロード
4. `Commit changes`
5. リポジトリの `Settings` → `Pages`
6. `Build and deployment` の Source を `Deploy from a branch`
7. Branch を `main`、フォルダを `/(root)` にして `Save`

## 文章を編集
`index.html` をGitHub上で開き、鉛筆アイコン（Edit this file）を押します。
例：「記憶を、次の挑戦へ。」を検索し、文字を変更して `Commit changes`。

## 写真を差し替える
`assets` 内の画像を同じファイル名で置き換えるのが最も簡単です。
例：トップ写真は `assets/hero.jpeg`。

## 主な画像
- hero.jpeg : トップ写真
- team.jpeg : ABOUT
- shishimai.jpeg : 伝統
- lanterns.jpeg : 竹灯籠・祭り
- children.jpeg : 子ども
- community.jpeg : 環境整備
- kumano.jpeg : 熊野神社
- art.jpeg : 地域アート
- redcarpet.jpeg : 雪浦ウィーク
